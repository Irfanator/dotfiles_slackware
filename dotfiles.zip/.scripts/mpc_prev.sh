#!/bin/sh
mpc prev; sleep 0.1; current=$(mpc current); notify-send "$current"
