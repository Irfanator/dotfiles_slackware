#!/bin/sh
mpc volume -3 ; notify-send $(mpc volume) -t 1600
