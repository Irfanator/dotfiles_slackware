#!/bin/sh
current=$(mpc current); notify-send "$current"
